#define LIBSSH2_VERSION_TEXT "Libssh2 1.8.0"

